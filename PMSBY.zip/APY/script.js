/* Atal Pension Yojana (APY) — Subscriber Registration Form
 * Form filling, autofill, auto-save (localStorage), import/export, print,
 * DOB -> age, and auto monthly-contribution from the official APY chart. */
(function () {
  "use strict";

  const STORAGE_KEY = "apy_srf_data_v1";
  const LOGO_KEY = "apy_bank_logo_v1";
  const form = document.getElementById("apyForm");
  const toastEl = document.getElementById("toast");

  /* ---------- Official APY indicative monthly contribution chart ----------
   * Key = entry age (years). Values are monthly contribution in Rs. for the
   * five guaranteed pension slabs: [1000, 2000, 3000, 4000, 5000]. */
  const APY_CHART = {
    18: [42, 84, 126, 168, 210],
    19: [46, 92, 138, 183, 228],
    20: [50, 100, 150, 198, 248],
    21: [54, 108, 162, 215, 269],
    22: [59, 117, 177, 234, 292],
    23: [64, 127, 192, 254, 318],
    24: [70, 139, 208, 277, 346],
    25: [76, 151, 226, 301, 376],
    26: [82, 164, 246, 327, 409],
    27: [90, 178, 268, 356, 446],
    28: [97, 194, 292, 388, 485],
    29: [106, 212, 318, 423, 529],
    30: [116, 231, 347, 462, 577],
    31: [126, 252, 379, 504, 630],
    32: [138, 276, 414, 551, 689],
    33: [151, 302, 453, 602, 752],
    34: [165, 330, 495, 659, 824],
    35: [181, 362, 543, 722, 902],
    36: [198, 396, 594, 792, 990],
    37: [218, 436, 654, 870, 1087],
    38: [240, 480, 720, 957, 1196],
    39: [264, 528, 792, 1054, 1318],
    40: [291, 582, 873, 1164, 1454],
  };
  const PENSION_SLABS = [1000, 2000, 3000, 4000, 5000];

  /* ---------- Helpers ---------- */
  function toast(msg) {
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    clearTimeout(toast._t);
    toast._t = setTimeout(() => toastEl.classList.remove("show"), 2200);
  }

  function collect() {
    const data = {};
    form.querySelectorAll("input, select, textarea").forEach((el) => {
      if (!el.name) return;
      if (el.type === "radio") {
        if (el.checked) data[el.name] = el.value;
        else if (!(el.name in data)) data[el.name] = data[el.name] || "";
      } else if (el.type === "checkbox") {
        data[el.name] = el.checked;
      } else {
        data[el.name] = el.value;
      }
    });
    return data;
  }

  function apply(data) {
    if (!data) return;
    Object.keys(data).forEach((name) => {
      const els = form.querySelectorAll('[name="' + CSS.escape(name) + '"]');
      if (!els.length) return;
      els.forEach((el) => {
        if (el.type === "radio") {
          el.checked = el.value === data[name];
        } else if (el.type === "checkbox") {
          el.checked = !!data[name];
        } else {
          el.value = data[name];
        }
      });
    });
    onMinorChange();
    syncGroupsFill();
    recalc();
    if (typeof syncPeriodicity === "function") syncPeriodicity();
  }

  /* ---------- Auto-save ---------- */
  let saveTimer;
  function autoSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(collect()));
      } catch (e) {
        /* storage may be unavailable; ignore */
      }
    }, 400);
  }

  function loadSaved(showMsg) {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) {
        if (showMsg) toast("No saved data found.");
        return false;
      }
      apply(JSON.parse(raw));
      if (showMsg) toast("Saved data loaded.");
      return true;
    } catch (e) {
      if (showMsg) toast("Could not load saved data.");
      return false;
    }
  }

  /* ---------- Age from DOB ---------- */
  function computeAge(dobStr) {
    if (!dobStr) return null;
    const dob = new Date(dobStr);
    if (isNaN(dob)) return null;
    const now = new Date();
    let age = now.getFullYear() - dob.getFullYear();
    const m = now.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < dob.getDate())) age--;
    return age;
  }

  /* ---------- Dynamic recalculation (age + contribution) ---------- */
  const ageEl = document.getElementById("age");
  const contributionEl = document.getElementById("contribution");
  const autoNoteEl = document.getElementById("autoNote");

  function selectedPension() {
    const el = form.querySelector('[name="pensionAmount"]:checked');
    return el ? parseInt(el.value, 10) : null;
  }

  function recalc() {
    const dob = document.getElementById("dob").value;
    const age = computeAge(dob);
    const pension = selectedPension();

    ageEl.value = age == null ? "" : age + " yrs";

    // Mirror values onto the acknowledgement page.
    const ackPension = document.getElementById("ackPensionAmount");
    if (ackPension) ackPension.value = pension ? pension.toLocaleString("en-IN") : "";

    // Screen-only hint (never printed). No "auto-filled" confirmation clutter.
    let note = "";
    let contribution = "";

    if (age != null && pension) {
      if (age < 18 || age > 40) {
        note = "Note: APY entry age must be between 18 and 40 years (current age " + age + ").";
      } else {
        const slabIdx = PENSION_SLABS.indexOf(pension);
        const row = APY_CHART[age];
        if (row && slabIdx > -1) contribution = String(row[slabIdx]);
      }
    }

    contributionEl.value = contribution;
    const ackContribution = document.getElementById("ackContribution");
    if (ackContribution) ackContribution.value = contribution;

    if (autoNoteEl) {
      autoNoteEl.textContent = note;
      autoNoteEl.classList.toggle("warn", !!note);
    }

    highlightChartRow(age);
  }

  /* ---------- Build & highlight reference chart ---------- */
  function buildChart() {
    const body = document.getElementById("chartBody");
    if (!body) return;
    let html = "";
    Object.keys(APY_CHART).forEach((age) => {
      const r = APY_CHART[age];
      html += '<tr data-age="' + age + '"><td>' + age + "</td>" +
        r.map((v) => "<td>" + v + "</td>").join("") + "</tr>";
    });
    body.innerHTML = html;
  }

  function highlightChartRow(age) {
    document.querySelectorAll("#chartBody tr").forEach((tr) => {
      tr.classList.toggle("match", String(age) === tr.getAttribute("data-age"));
    });
  }

  /* ---------- Repeated-field sync (type once, fill everywhere) ----------
   * Each group lists element IDs that represent the SAME piece of data in
   * different places on the form. Typing in any one fills all the others. */
  const SYNC_GROUPS = [
    ["toBankName", "bankName", "ackBankName"],     // Bank name (To-line, Bank Details, Acknowledgement)
    ["toBranch", "bankBranch", "ackBankBranch"],   // Branch (To-line, Bank Details, Acknowledgement)
    ["fullName", "ackSubscriberName"],             // Applicant / Subscriber name
  ];
  let syncing = false;

  function groupOf(id) {
    return SYNC_GROUPS.find((g) => g.indexOf(id) > -1);
  }

  // Live: copy the edited field's value to every other field in its group.
  function propagateFrom(el) {
    if (syncing) return;
    const group = groupOf(el.id);
    if (!group) return;
    syncing = true;
    group.forEach((id) => {
      if (id === el.id) return;
      const t = document.getElementById(id);
      if (t && t.value !== el.value) t.value = el.value;
    });
    syncing = false;
  }

  // Fill any empty member of each group from a non-empty sibling.
  // Used after load / import / sample so repeated values appear everywhere.
  function syncGroupsFill() {
    SYNC_GROUPS.forEach((g) => {
      let val = "";
      for (let i = 0; i < g.length; i++) {
        const el = document.getElementById(g[i]);
        if (el && el.value) { val = el.value; break; }
      }
      if (!val) return;
      g.forEach((id) => {
        const el = document.getElementById(id);
        if (el && !el.value) el.value = val;
      });
    });
  }

  /* ---------- Custom bank logo (left header) ---------- */
  const logoBox = document.getElementById("apyLogo");
  const logoImg = document.getElementById("bankLogoImg");
  const logoText = document.getElementById("apyLogoText");
  const btnRemoveLogo = document.getElementById("btnRemoveLogo");

  // Show/hide the custom logo. Pass a data-URL string, or null to revert to text.
  function setBankLogo(dataUrl) {
    if (dataUrl) {
      logoImg.src = dataUrl;
      logoImg.hidden = false;
      logoText.hidden = true;
      logoBox.classList.add("has-logo");
      logoBox.classList.remove("logo-empty");
      btnRemoveLogo.hidden = false;
    } else {
      // No logo loaded: keep the left box invisible (blank).
      logoImg.removeAttribute("src");
      logoImg.hidden = true;
      logoText.hidden = true;
      logoBox.classList.remove("has-logo");
      logoBox.classList.add("logo-empty");
      btnRemoveLogo.hidden = true;
    }
  }

  function loadBankLogo() {
    let saved = null;
    try {
      saved = localStorage.getItem(LOGO_KEY);
    } catch (e) {
      /* ignore */
    }
    setBankLogo(saved || null);
  }

  function handleLogoFile(file) {
    if (!file.type || file.type.indexOf("image/") !== 0) {
      toast("Please choose an image file.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result;
      setBankLogo(dataUrl);
      try {
        localStorage.setItem(LOGO_KEY, dataUrl);
      } catch (e) {
        toast("Logo shown, but too large to save in this browser.");
        return;
      }
      toast("Bank logo added.");
    };
    reader.readAsDataURL(file);
  }

  /* ---------- Minor-nominee toggle ---------- */
  function onMinorChange() {
    const minor = document.getElementById("nomineeMinor").checked;
    document.getElementById("minorFields").classList.toggle("disabled", !minor);
  }

  /* ---------- Mandatory-field validation ---------- */
  // Base mandatory fields (marked * on the form). Conditional ones added below.
  const REQUIRED = [
    { name: "bankAccNo", label: "Bank A/c Number" },
    { name: "bankName", label: "Bank Name" },
    { name: "bankBranch", label: "Bank Branch" },
    { name: "fullName", label: "Full Name of Applicant" },
    { name: "dob", label: "Date of Birth" },
    { name: "mobile", label: "Mobile No" },
    { name: "nomineeName", label: "Nominee's Name" },
    { name: "nomineeRelation", label: "Nominee's relationship with the subscriber" },
    { name: "pensionAmount", label: "Pension Amount" },
  ];

  function fieldValue(name) {
    const els = form.querySelectorAll('[name="' + CSS.escape(name) + '"]');
    if (!els.length) return "";
    const first = els[0];
    if (first.type === "radio") {
      const checked = form.querySelector('[name="' + CSS.escape(name) + '"]:checked');
      return checked ? checked.value : "";
    }
    return (first.value || "").trim();
  }

  function markInvalid(name, bad) {
    form.querySelectorAll('[name="' + CSS.escape(name) + '"]').forEach((el) => {
      const target = el.type === "radio" ? el.closest(".frow") : el;
      if (target) target.classList.toggle("invalid", bad);
    });
  }

  function clearInvalidOnInput() {
    form.querySelectorAll(".invalid").forEach((el) => el.classList.remove("invalid"));
  }

  // Returns an array of missing-field labels; also flags them in the UI.
  function validateRequired() {
    const rules = REQUIRED.slice();
    // Conditional: spouse name required when married = Yes.
    if (fieldValue("married") === "Yes") {
      rules.push({ name: "spouseName", label: "Name of Spouse (married)" });
    }
    // Conditional: minor nominee needs DOB + guardian name.
    if (document.getElementById("nomineeMinor").checked) {
      rules.push({ name: "nomineeDob", label: "Nominee Date of Birth (minor)" });
      rules.push({ name: "guardianName", label: "Guardian's Name (minor)" });
    }

    const missing = [];
    rules.forEach((r) => {
      const empty = !fieldValue(r.name);
      markInvalid(r.name, empty);
      if (empty) missing.push(r);
    });
    return missing;
  }

  /* ---------- Format / date validation ---------- */
  const FORMAT_RULES = [
    { name: "mobile", label: "Mobile No", test: (v) => /^[6-9]\d{9}$/.test(v), msg: "must be 10 digits starting 6\u20139" },
    { name: "email", label: "Email", test: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), msg: "enter a valid email address" },
    { name: "aadhaar", label: "Aadhaar", test: (v) => /^\d{12}$/.test(v.replace(/\s/g, "")), msg: "Aadhaar must be 12 digits" },
    { name: "spouseAadhaar", label: "Spouse's Aadhaar", test: (v) => /^\d{12}$/.test(v.replace(/\s/g, "")), msg: "Aadhaar must be 12 digits" },
    { name: "nomineeAadhaar", label: "Nominee's Aadhaar", test: (v) => /^\d{12}$/.test(v.replace(/\s/g, "")), msg: "Aadhaar must be 12 digits" },
    { name: "bankAccNo", label: "Bank A/c Number", test: (v) => /^\d{9,18}$/.test(v), msg: "account number must be 9\u201318 digits" },
  ];

  function isFutureDate(str) {
    const d = new Date(str);
    if (isNaN(d.getTime())) return false;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    return d > today;
  }

  // Returns an array of {name,label,msg} for badly formatted non-empty fields.
  function validateFormats() {
    const issues = [];
    FORMAT_RULES.forEach((r) => {
      const v = fieldValue(r.name);
      if (v && !r.test(v)) {
        markInvalid(r.name, true);
        issues.push({ name: r.name, label: r.label, msg: r.msg });
      }
    });
    const dob = fieldValue("dob");
    if (dob) {
      if (isNaN(new Date(dob).getTime())) {
        markInvalid("dob", true);
        issues.push({ name: "dob", label: "Date of Birth", msg: "enter a valid date" });
      } else if (isFutureDate(dob)) {
        markInvalid("dob", true);
        issues.push({ name: "dob", label: "Date of Birth", msg: "cannot be in the future" });
      } else {
        const age = computeAge(dob);
        if (age != null && (age < 18 || age > 40)) {
          markInvalid("dob", true);
          issues.push({ name: "dob", label: "Date of Birth", msg: "APY entry age must be 18\u201340 (current " + age + ")" });
        }
      }
    }
    const ndob = fieldValue("nomineeDob");
    if (ndob && isFutureDate(ndob)) {
      markInvalid("nomineeDob", true);
      issues.push({ name: "nomineeDob", label: "Nominee Date of Birth", msg: "cannot be in the future" });
    }
    return issues;
  }

  // Combined required + format validation. Returns array of {name,label,msg}.
  function runFullValidation() {
    clearInvalidOnInput();
    const missing = validateRequired().map((m) => ({ name: m.name, label: m.label, msg: "required" }));
    return missing.concat(validateFormats());
  }

  function focusIssue(list) {
    if (!list.length) return;
    const first = form.querySelector('[name="' + CSS.escape(list[0].name) + '"]');
    if (first && first.focus) {
      first.scrollIntoView({ behavior: "smooth", block: "center" });
      try { first.focus({ preventScroll: true }); } catch (e) { first.focus(); }
    }
  }

  /* ---------- Sample data ---------- */
  const SAMPLE = {
    toBankName: "State Bank of India",
    toBranch: "Imphal Main",
    bankAccNo: "30123456789",
    bankName: "State Bank of India",
    bankBranch: "Imphal Main",
    title: "Shri",
    fullName: "RAHUL KUMAR SHARMA",
    dob: "1995-08-15",
    mobile: "9876543210",
    email: "rahul.sharma@example.com",
    aadhaar: "1234 5678 9012",
    married: "Yes",
    spouseName: "ANITA SHARMA",
    spouseAadhaar: "2345 6789 0123",
    nomineeName: "ANITA SHARMA",
    nomineeAadhaar: "2345 6789 0123",
    nomineeRelation: "Spouse",
    nomineeMinor: false,
    otherSocialScheme: "No",
    incomeTaxPayer: "No",
    fatcaCrs: "No",
    pensionAmount: "5000",
    frequency: "Monthly",
    declPlace: "Imphal",
    declDate: new Date().toISOString().slice(0, 10),
    ackBankName: "State Bank of India",
    ackBankBranch: "Imphal Main",
    periodicity: "Monthly",
  };

  /* ---------- Export / Import (CSV) ---------- */
  // Escape a single CSV cell per RFC 4180.
  function csvCell(value) {
    const s = value == null ? "" : String(value);
    return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  }

  // Parse CSV text into an array of rows (each row is an array of cells).
  function parseCSV(text) {
    const rows = [];
    let row = [];
    let cell = "";
    let inQuotes = false;
    const s = text.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
    for (let i = 0; i < s.length; i++) {
      const c = s[i];
      if (inQuotes) {
        if (c === '"') {
          if (s[i + 1] === '"') { cell += '"'; i++; }
          else inQuotes = false;
        } else cell += c;
      } else if (c === '"') {
        inQuotes = true;
      } else if (c === ",") {
        row.push(cell); cell = "";
      } else if (c === "\n") {
        row.push(cell); cell = "";
        rows.push(row); row = [];
      } else cell += c;
    }
    if (cell.length || row.length) { row.push(cell); rows.push(row); }
    return rows;
  }

  function exportCSV() {
    const data = collect();
    const lines = ["Field,Value"];
    Object.keys(data).forEach((name) => {
      lines.push(csvCell(name) + "," + csvCell(data[name]));
    });
    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], { type: "text/csv;charset=utf-8;" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "apy-srf-" + new Date().toISOString().slice(0, 10) + ".csv";
    a.click();
    URL.revokeObjectURL(a.href);
    toast("Exported CSV.");
  }

  function importCSV(file) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        let text = reader.result;
        if (text.charCodeAt(0) === 0xfeff) text = text.slice(1); // strip BOM
        const rows = parseCSV(text);
        if (!rows.length) throw new Error("empty");
        const data = {};
        let start = 0;
        // Skip a header row like "Field,Value" if present.
        const h0 = (rows[0][0] || "").trim().toLowerCase();
        const h1 = (rows[0][1] || "").trim().toLowerCase();
        if (h0 === "field" && h1 === "value") start = 1;
        for (let i = start; i < rows.length; i++) {
          const key = (rows[i][0] || "").trim();
          if (!key) continue;
          let val = rows[i][1] != null ? rows[i][1] : "";
          if (val === "true") val = true;
          else if (val === "false") val = false;
          data[key] = val;
        }
        apply(data);
        autoSave();
        toast("Imported CSV.");
      } catch (e) {
        toast("Invalid CSV file.");
      }
    };
    reader.readAsText(file);
  }

  /* ---------- Wire up events ---------- */
  document.getElementById("btnSample").addEventListener("click", () => {
    apply(SAMPLE);
    autoSave();
    toast("Sample data filled.");
  });
  document.getElementById("btnSave").addEventListener("click", () => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(collect()));
      toast("Form saved to this browser.");
    } catch (e) {
      toast("Save failed (storage blocked).");
    }
  });
  document.getElementById("btnLoad").addEventListener("click", () => loadSaved(true));
  document.getElementById("btnClear").addEventListener("click", () => {
    if (confirm("Clear all fields? This cannot be undone.")) {
      form.reset();
      document.getElementById("periodicity").value = "Monthly";
      localStorage.removeItem(STORAGE_KEY);
      onMinorChange();
      recalc();
      toast("Form cleared.");
    }
  });
  document.getElementById("btnExport").addEventListener("click", exportCSV);
  document.getElementById("importFile").addEventListener("change", (e) => {
    if (e.target.files[0]) importCSV(e.target.files[0]);
    e.target.value = "";
  });
  document.getElementById("bankLogoFile").addEventListener("change", (e) => {
    if (e.target.files[0]) handleLogoFile(e.target.files[0]);
    e.target.value = "";
  });
  btnRemoveLogo.addEventListener("click", () => {
    setBankLogo(null);
    try { localStorage.removeItem(LOGO_KEY); } catch (e) { /* ignore */ }
    toast("Bank logo removed.");
  });
  document.getElementById("btnPrint").addEventListener("click", () => {
    syncGroupsFill();
    const issues = runFullValidation();
    if (issues.length) {
      focusIssue(issues);
      toast(
        issues.length + " issue" + (issues.length > 1 ? "s" : "") +
        " \u2014 " + issues[0].label + ": " + issues[0].msg
      );
      return;
    }
    window.print();
  });

  // Floating "Validate" button — checks formats, dates and mandatory fields.
  function validateOnly() {
    syncGroupsFill();
    const issues = runFullValidation();
    if (!issues.length) {
      toast("\u2713 All entries look valid.");
    } else {
      focusIssue(issues);
      toast(
        "\u26A0 " + issues.length + " issue" + (issues.length > 1 ? "s" : "") +
        " \u2014 fix highlighted fields. First: " + issues[0].label + ": " + issues[0].msg
      );
    }
  }
  (function addValidateFab() {
    if (document.getElementById("fabValidate")) return;
    const fab = document.createElement("button");
    fab.type = "button";
    fab.id = "fabValidate";
    fab.className = "fab no-print";
    fab.title = "Validate the details you entered";
    fab.innerHTML = '<span class="fab-ic">\u2713</span><span class="fab-tx">Validate</span>';
    fab.addEventListener("click", validateOnly);
    document.body.appendChild(fab);
  })();

  /* ---------- Preview (on-screen A4 print preview) ---------- */
  function measureFit(runId) {
    const MM = 3.7795275591; // px per mm at 96 CSS dpi
    const doc = document.querySelector(".apy-doc");
    const docPx = doc ? doc.getBoundingClientRect().height : 0;
    const availMM = 297 - 14; // printable band height at 7mm top+bottom margins
    const docMM = docPx / MM;
    const overMM = docMM - availMM;
    const banner = document.getElementById("previewBanner");
    if (banner) {
      banner.hidden = false;
      if (overMM > 0.5) {
        banner.className = "preview-banner no-print over";
        banner.textContent =
          "\u26A0 Overflows one A4 page by ~" + Math.ceil(overMM) +
          " mm (content " + Math.round(docMM) + "mm / " + availMM + "mm available)";
      } else {
        banner.className = "preview-banner no-print fit";
        banner.textContent =
          "\u2713 Fits on one A4 page (content " + Math.round(docMM) +
          "mm / " + availMM + "mm available)";
      }
    }
    debugMeasure(runId || "preview", "preview");
  }

  function setPreview(on) {
    document.body.classList.toggle("preview-mode", on);
    document.body.classList.toggle("compact", on);
    const btn = document.getElementById("btnPreview");
    if (btn) btn.textContent = on ? "Exit Preview" : "Preview";
    if (on) {
      requestAnimationFrame(() => measureFit("post-fix"));
    } else {
      const banner = document.getElementById("previewBanner");
      if (banner) banner.hidden = true;
    }
  }
  document.getElementById("btnPreview").addEventListener("click", () => {
    setPreview(!document.body.classList.contains("preview-mode"));
  });

  document.getElementById("nomineeMinor").addEventListener("change", () => {
    onMinorChange();
    autoSave();
  });

  // Recalculate age/contribution on relevant changes.
  document.getElementById("dob").addEventListener("input", recalc);
  form.querySelectorAll('[name="pensionAmount"]').forEach((el) =>
    el.addEventListener("change", () => {
      recalc();
      autoSave();
    })
  );

  // Mirror selected contribution frequency into the acknowledgement periodicity.
  function syncPeriodicity() {
    const f = form.querySelector('[name="frequency"]:checked');
    const p = document.getElementById("periodicity");
    if (p) p.value = f ? f.value : "Monthly";
  }
  form.querySelectorAll('[name="frequency"]').forEach((el) =>
    el.addEventListener("change", () => {
      syncPeriodicity();
      autoSave();
    })
  );
  syncPeriodicity();

  // Uppercase guards.
  form.querySelectorAll(".upper").forEach((el) =>
    el.addEventListener("input", () => (el.value = el.value.toUpperCase()))
  );

  // Numeric-only guards.
  ["mobile", "bankAccNo"].forEach((id) => {
    const el = document.getElementById(id);
    if (el) el.addEventListener("input", () => (el.value = el.value.replace(/\D/g, "")));
  });

  // Repeated-field sync: typing in any grouped field fills the others live.
  SYNC_GROUPS.forEach((g) => {
    g.forEach((id) => {
      const el = document.getElementById(id);
      if (el) el.addEventListener("input", () => propagateFrom(el));
    });
  });

  // Auto-save on any change/input.
  form.addEventListener("input", autoSave);
  form.addEventListener("change", autoSave);

  // Remove validation highlights as the user fills fields.
  form.addEventListener("input", clearInvalidOnInput);
  form.addEventListener("change", clearInvalidOnInput);

  // #region agent log
  // DEBUG: measure compact/print-layout heights to diagnose single-page overflow.
  function debugMeasure(runId, ctx) {
    try {
      var MM = 3.7795275591; // px per mm at 96 CSS dpi
      var q = function (s) { return document.querySelector(s); };
      var h = function (el) { return el ? Math.round(el.getBoundingClientRect().height) : null; };
      var grids = document.querySelectorAll(".grid-block");
      var helper = q(".helper");
      var data = {
        ctx: ctx,
        compactOn: document.body.classList.contains("compact"),
        apyDocPx: h(q(".apy-doc")),
        pagePx: h(q(".page")),
        a4FullPx: Math.round(297 * MM),
        printable_7mm: Math.round((297 - 14) * MM),
        printable_12_7mm: Math.round((297 - 25.4) * MM),
        cellInputPx: h(q(".cell-input")),
        helperDisplay: helper ? getComputedStyle(helper).display : "n/a",
        headPx: h(q(".apy-head")),
        grid1Px: h(grids[0]),
        grid2Px: h(grids[1]),
        grid3Px: h(grids[2]),
        declPx: h(q(".declaration")),
        ackPx: h(q(".ack")),
        bodyFontPx: getComputedStyle(document.body).fontSize,
        innerW: window.innerWidth, innerH: window.innerHeight, dpr: window.devicePixelRatio
      };
      fetch('http://127.0.0.1:7520/ingest/95f1dc3e-2ad6-40a8-a0da-caa8548c4c56', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': '7660ef' }, body: JSON.stringify({ sessionId: '7660ef', runId: runId, hypothesisId: 'A,B,C,D', location: 'script.js:debugMeasure', message: 'layout measurements', data: data, timestamp: Date.now() }) }).catch(function () {});
    } catch (e) {
      fetch('http://127.0.0.1:7520/ingest/95f1dc3e-2ad6-40a8-a0da-caa8548c4c56', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Debug-Session-Id': '7660ef' }, body: JSON.stringify({ sessionId: '7660ef', runId: runId, hypothesisId: 'A,B,C,D', location: 'script.js:debugMeasure', message: 'measure error', data: { err: String(e) }, timestamp: Date.now() }) }).catch(function () {});
    }
  }
  window.addEventListener("beforeprint", function () {
    document.body.classList.add("compact"); // print uses the shared compact layout
    debugMeasure("post-fix", "beforeprint");
  });
  window.addEventListener("afterprint", function () {
    if (!document.body.classList.contains("preview-mode")) {
      document.body.classList.remove("compact");
    }
  });
  // #endregion

  /* ---------- Init ---------- */
  buildChart();
  loadBankLogo();
  loadSaved(false);
  onMinorChange();
  recalc();
})();
