(function () {
  "use strict";

  var STORE_KEY = "form121.data.v1";
  var $ = function (id) { return document.getElementById(id); };

  /* ---------- Toast ---------- */
  var toastEl = $("toast");
  var toastTimer = null;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove("show"); }, 2600);
  }

  /* ---------- Field registry ---------- */
  // All persisted scalar fields (id-based).
  var FIELDS = [
    "decName", "decPan", "decStatus", "decResidential", "decDob", "decTaxYear",
    "addrFlat", "addrPremises", "addrStreet", "addrArea", "addrCity", "addrState", "addrPin",
    "decEmail", "decMobile", "decAssessed", "decAssessYear",
    "itrYear1", "itrAck1", "itrInc1", "itrYear2", "itrAck2", "itrInc2",
    "estTotalIncome", "otherCount", "aggAll",
    "declPlace", "declDate",
    "payName", "payPan", "payTan", "payTaxYear", "payEmail", "payContact",
    "payAddress", "payUin", "bReceived", "payPlace", "payDate"
  ];

  var REQUIRED = [
    "decName", "decPan", "decStatus", "decResidential", "decDob", "decTaxYear",
    "addrCity", "addrState", "addrPin", "decEmail", "decMobile", "estTotalIncome"
  ];

  function incomeInputs() {
    return Array.prototype.slice.call(document.querySelectorAll("#incomeRows [data-inc]"));
  }

  /* ---------- Collect / apply (persistence + CSV) ---------- */
  function collect() {
    var data = {};
    FIELDS.forEach(function (id) { var el = $(id); if (el) data[id] = el.value; });
    var inc = [];
    var rows = document.querySelectorAll("#incomeRows tr");
    rows.forEach(function (tr) {
      var get = function (k) { var el = tr.querySelector('[data-inc="' + k + '"]'); return el ? el.value : ""; };
      inc.push({ id: get("id"), nature: get("nature"), section: get("section"), amount: get("amount") });
    });
    data.__income = inc;
    return data;
  }

  function apply(data) {
    if (!data) return;
    FIELDS.forEach(function (id) { var el = $(id); if (el && data[id] != null) el.value = data[id]; });
    if (Array.isArray(data.__income)) {
      var rows = document.querySelectorAll("#incomeRows tr");
      data.__income.forEach(function (r, i) {
        if (!rows[i]) return;
        ["id", "nature", "section", "amount"].forEach(function (k) {
          var el = rows[i].querySelector('[data-inc="' + k + '"]');
          if (el && r[k] != null) el.value = r[k];
        });
      });
    }
    recompute();
    syncPartB();
  }

  /* ---------- Auto-save ---------- */
  function save() {
    try { localStorage.setItem(STORE_KEY, JSON.stringify(collect())); } catch (e) {}
  }
  function load() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      if (raw) apply(JSON.parse(raw));
    } catch (e) {}
  }

  /* ---------- Numbers ---------- */
  function toNum(v) {
    var n = parseFloat(String(v || "").replace(/[^0-9.\-]/g, ""));
    return isNaN(n) ? 0 : n;
  }
  function fmt(n) {
    if (!n) return "";
    return n.toLocaleString("en-IN");
  }

  function recompute() {
    var sum = 0;
    incomeInputs().forEach(function (el) {
      if (el.getAttribute("data-inc") === "amount") sum += toNum(el.value);
    });
    if ($("aggThis")) $("aggThis").value = fmt(sum);
  }

  /* ---------- Part A -> Part B + declaration sync ---------- */
  function syncPartB() {
    var addr = [
      $("addrFlat").value, $("addrPremises").value, $("addrStreet").value,
      $("addrArea").value, $("addrCity").value, $("addrState").value, $("addrPin").value
    ].filter(Boolean).join(", ");

    var contact = [$("decEmail").value, $("decMobile").value].filter(Boolean).join(" / ");

    $("bName").value = $("decName").value;
    $("bPan").value = $("decPan").value;
    $("bDob").value = $("decDob").value;
    $("bAddr").value = addr;
    $("bContact").value = contact;
    $("bEstIncome").value = $("aggThis").value;
    $("bEstTotal").value = $("estTotalIncome").value ? fmt(toNum($("estTotalIncome").value)) : "";
    $("bAggregate").value = $("aggAll").value ? fmt(toNum($("aggAll").value)) : $("aggThis").value;

    // Declaration inline mirrors
    $("declSelfName").value = $("decName").value;
    $("declTaxYear").value = $("decTaxYear").value;

    // UIN top mirror from Part B
    $("uinTop").value = $("payUin").value;
  }

  /* ---------- Validation ---------- */
  function isPan(v) { return /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(String(v || "").toUpperCase()); }
  function isTan(v) { return /^[A-Z]{4}[0-9]{5}[A-Z]$/.test(String(v || "").toUpperCase()); }
  function isFutureDate(str) {
    var d = new Date(str);
    if (isNaN(d.getTime())) return false;
    var today = new Date(); today.setHours(0, 0, 0, 0);
    return d > today;
  }
  var LABELS = {
    decName: "Name of declarant", decPan: "PAN of declarant", decEmail: "Email",
    decMobile: "Mobile", addrPin: "PIN code", decDob: "Date of birth",
    payPan: "PAN of payer", payEmail: "Payer email", payTan: "TAN of payer", declDate: "Declaration date"
  };
  function labelOf(el) { return LABELS[el.id] || el.id; }

  // Format checks for non-empty fields. Returns {el,msg} or null.
  function formatError(el) {
    var v = String(el.value || "").trim();
    if (!v) return null;
    switch (el.id) {
      case "decPan":
      case "payPan": return isPan(v) ? null : "enter a valid PAN (e.g. ABCDE1234F)";
      case "payTan": return isTan(v) ? null : "enter a valid TAN (e.g. BLRS12345E)";
      case "decEmail":
      case "payEmail": return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? null : "enter a valid email address";
      case "decMobile": return /^[6-9]\d{9}$/.test(v) ? null : "mobile must be 10 digits starting 6\u20139";
      case "addrPin": return /^\d{6}$/.test(v) ? null : "PIN code must be 6 digits";
      case "decDob": return isFutureDate(v) ? "date of birth cannot be in the future" : null;
      default: return null;
    }
  }

  function clearInvalid() {
    document.querySelectorAll(".cell.invalid").forEach(function (el) { el.classList.remove("invalid"); });
  }

  function runValidation() {
    clearInvalid();
    var firstBad = null, issues = [];
    REQUIRED.forEach(function (id) {
      var el = $(id);
      if (el && !String(el.value).trim()) {
        el.classList.add("invalid");
        if (!firstBad) firstBad = el;
        issues.push(labelOf(el) + ": required");
      }
    });
    ["decPan", "payPan", "payTan", "decEmail", "payEmail", "decMobile", "addrPin", "decDob"].forEach(function (id) {
      var el = $(id);
      if (!el) return;
      var msg = formatError(el);
      if (msg) {
        el.classList.add("invalid");
        if (!firstBad) firstBad = el;
        issues.push(labelOf(el) + ": " + msg);
      }
    });
    return { ok: !firstBad, firstBad: firstBad, issues: issues };
  }
  function focusBad(r) {
    if (!r.firstBad) return;
    r.firstBad.scrollIntoView({ behavior: "smooth", block: "center" });
    try { r.firstBad.focus({ preventScroll: true }); } catch (e) {}
  }
  function validate() {
    var r = runValidation();
    if (!r.ok) {
      focusBad(r);
      toast(r.issues.length + " issue(s) \u2014 " + r.issues[0]);
    }
    return r.ok;
  }
  function validateOnly() {
    var r = runValidation();
    if (r.ok) {
      toast("\u2713 All entries look valid.");
    } else {
      focusBad(r);
      toast("\u26A0 " + r.issues.length + " issue(s) \u2014 fix highlighted fields. First: " + r.issues[0]);
    }
  }

  /* ---------- Sample ---------- */
  function fillSample() {
    apply({
      decName: "Ramesh Kumar Sharma", decPan: "ABCPK1234M", decStatus: "Individual",
      decResidential: "Resident", decDob: "1968-07-15", decTaxYear: "2026-27",
      addrFlat: "12B", addrPremises: "Sunrise Apartments", addrStreet: "MG Road",
      addrArea: " Shanti Nagar".trim(), addrCity: "Bengaluru", addrState: "Karnataka", addrPin: "560001",
      decEmail: "ramesh.sharma@example.com", decMobile: "9845012345",
      decAssessed: "Yes", decAssessYear: "2025-26",
      itrYear1: "2025-26", itrAck1: "5601234567890123", itrInc1: "320000",
      itrYear2: "2024-25", itrAck2: "5609876543210987", itrInc2: "298000",
      estTotalIncome: "350000", otherCount: "1", aggAll: "95000",
      declPlace: "Bengaluru", declDate: new Date().toISOString().slice(0, 10),
      payName: "State Bank of India, MG Road Branch", payPan: "AAACS1234K", payTan: "BLRS12345E",
      payTaxYear: "2026-27", payEmail: "mgroad.branch@sbi.co.in", payContact: "0801234567",
      payAddress: "MG Road, Bengaluru, Karnataka 560001",
      payUin: "D000000451202627BLRS12345E",
      bReceived: new Date().toISOString().slice(0, 10),
      __income: [
        { id: "FD-3041992210", nature: "Interest on fixed deposit", section: "393", amount: "62000" },
        { id: "SB-3041880011", nature: "Interest on savings account", section: "393", amount: "8500" },
        { id: "", nature: "", section: "", amount: "" }
      ]
    });
    save();
    toast("Sample data filled.");
  }

  function clearAll() {
    if (!confirm("Clear all fields? This cannot be undone.")) return;
    FIELDS.forEach(function (id) { var el = $(id); if (el) el.value = ""; });
    incomeInputs().forEach(function (el) { el.value = ""; });
    clearInvalid();
    recompute();
    syncPartB();
    save();
    toast("Form cleared.");
  }

  /* ---------- CSV ---------- */
  function csvEscape(v) {
    v = String(v == null ? "" : v);
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function exportCSV() {
    var data = collect();
    var rows = [["field", "value"]];
    FIELDS.forEach(function (id) { rows.push([id, data[id] || ""]); });
    (data.__income || []).forEach(function (r, i) {
      rows.push(["income" + (i + 1) + ".id", r.id]);
      rows.push(["income" + (i + 1) + ".nature", r.nature]);
      rows.push(["income" + (i + 1) + ".section", r.section]);
      rows.push(["income" + (i + 1) + ".amount", r.amount]);
    });
    var csv = rows.map(function (r) { return r.map(csvEscape).join(","); }).join("\r\n");
    var blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "form121-" + (($("decPan").value || "data").toUpperCase()) + ".csv";
    a.click();
    URL.revokeObjectURL(a.href);
    toast("CSV exported.");
  }
  function parseCSV(text) {
    var rows = [], row = [], cur = "", q = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += c;
      } else {
        if (c === '"') q = true;
        else if (c === ",") { row.push(cur); cur = ""; }
        else if (c === "\n") { row.push(cur); rows.push(row); row = []; cur = ""; }
        else if (c !== "\r") cur += c;
      }
    }
    if (cur !== "" || row.length) { row.push(cur); rows.push(row); }
    return rows;
  }
  function importCSV(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var rows = parseCSV(String(reader.result));
        var map = {};
        rows.slice(1).forEach(function (r) { if (r[0]) map[r[0]] = r[1] != null ? r[1] : ""; });
        var data = {};
        FIELDS.forEach(function (id) { if (map[id] != null) data[id] = map[id]; });
        var inc = [];
        for (var i = 1; i <= 3; i++) {
          inc.push({
            id: map["income" + i + ".id"] || "", nature: map["income" + i + ".nature"] || "",
            section: map["income" + i + ".section"] || "", amount: map["income" + i + ".amount"] || ""
          });
        }
        data.__income = inc;
        apply(data);
        save();
        toast("CSV imported.");
      } catch (e) { toast("Could not read CSV file."); }
    };
    reader.readAsText(file);
  }

  /* ---------- Preview ---------- */
  function measureFit() {
    var MM = 3.7795275591;
    var doc = document.querySelector(".doc");
    var docMM = (doc ? doc.getBoundingClientRect().height : 0) / MM;
    // two A4 pages available (Part B starts on page 2)
    var availMM = (297 - 20) * 2;
    var banner = $("previewBanner");
    if (!banner) return;
    banner.hidden = false;
    if (docMM > availMM + 1) {
      banner.className = "preview-banner no-print over";
      banner.textContent = "\u26A0 Content is long (~" + Math.round(docMM) + "mm). It may run beyond 2 pages.";
    } else {
      banner.className = "preview-banner no-print fit";
      banner.textContent = "\u2713 Print layout ready (Part A on page 1, Part B on page 2).";
    }
  }
  function setPreview(on) {
    document.body.classList.toggle("preview-mode", on);
    var btn = $("btnPreview");
    if (btn) btn.textContent = on ? "Exit Preview" : "Preview";
    if (on) requestAnimationFrame(measureFit);
    else { var b = $("previewBanner"); if (b) b.hidden = true; }
  }

  /* ---------- Wire up ---------- */
  function onAnyInput(e) {
    var t = e.target;
    if (t && t.classList && t.classList.contains("invalid")) t.classList.remove("invalid");
    if (t && t.getAttribute && t.getAttribute("data-inc") === "amount") recompute();
    syncPartB();
    save();
  }

  document.addEventListener("DOMContentLoaded", function () {
    load();
    if (!$("decTaxYear").value) $("decTaxYear").value = "2026-27";
    if (!$("payTaxYear").value) $("payTaxYear").value = "2026-27";
    syncPartB();

    document.getElementById("f121").addEventListener("input", onAnyInput);
    document.getElementById("f121").addEventListener("change", onAnyInput);

    $("btnSample").addEventListener("click", fillSample);
    $("btnClear").addEventListener("click", clearAll);
    $("btnExport").addEventListener("click", exportCSV);
    $("importCsv").addEventListener("change", function (e) {
      if (e.target.files && e.target.files[0]) importCSV(e.target.files[0]);
      e.target.value = "";
    });
    $("btnPreview").addEventListener("click", function () {
      setPreview(!document.body.classList.contains("preview-mode"));
    });
    $("btnPrint").addEventListener("click", function () {
      if (validate()) window.print();
    });

    if (!$("fabValidate")) {
      var fab = document.createElement("button");
      fab.type = "button";
      fab.id = "fabValidate";
      fab.className = "fab no-print";
      fab.title = "Validate the details you entered";
      fab.innerHTML = '<span class="fab-ic">\u2713</span><span class="fab-tx">Validate</span>';
      fab.addEventListener("click", validateOnly);
      document.body.appendChild(fab);
    }
  });
})();
