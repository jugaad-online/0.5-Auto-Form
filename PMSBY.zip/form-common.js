/*
 * Generic fillable-form engine shared by all scheme forms.
 *
 * A form page only needs:
 *   - a #docForm element wrapping the fields
 *   - inputs/selects/textareas with unique ids
 *   - optional: window.FORM_KEY (storage key), window.FORM_SAMPLE (sample data map)
 *   - optional toolbar buttons by id: btnSample, btnClear, btnExport, importCsv,
 *     btnPreview, btnPrint
 *   - mirrors: any element with data-mirror="sourceId" auto-copies that field's value
 *   - required fields: native `required` attribute; PAN check via class "pan"
 */
(function () {
  "use strict";

  var $ = function (id) { return document.getElementById(id); };
  var form = $("docForm");
  if (!form) return;

  var STORE_KEY = window.FORM_KEY || ("form." + location.pathname);
  var SAMPLE = window.FORM_SAMPLE || null;

  /* ---------- Toast ---------- */
  var toastEl = $("toast");
  var toastTimer = null;
  function toast(msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove("show"); }, 2600);
  }

  /* ---------- Field discovery ---------- */
  function controls() {
    return Array.prototype.slice
      .call(form.querySelectorAll("input, select, textarea"))
      .filter(function (el) { return el.id && el.type !== "file"; });
  }

  function getVal(el) {
    if (el.type === "checkbox") return el.checked ? "1" : "";
    if (el.type === "radio") {
      var picked = form.querySelector('input[name="' + el.name + '"]:checked');
      return picked ? picked.value : "";
    }
    return el.value;
  }
  function setVal(el, v) {
    if (el.type === "checkbox") { el.checked = v === "1" || v === true || v === "true"; return; }
    if (el.type === "radio") { el.checked = (el.value === v); return; }
    el.value = v == null ? "" : v;
  }

  /* ---------- Collect / apply ---------- */
  function collect() {
    var data = {};
    controls().forEach(function (el) {
      if (el.type === "radio") { if (el.checked) data[el.name] = el.value; }
      else data[el.id] = getVal(el);
    });
    return data;
  }
  function apply(data) {
    if (!data) return;
    controls().forEach(function (el) {
      if (el.type === "radio") { if (data[el.name] != null) el.checked = (el.value === data[el.name]); }
      else if (data[el.id] != null) setVal(el, data[el.id]);
    });
    mirror();
  }

  /* ---------- Persistence ---------- */
  function save() { try { localStorage.setItem(STORE_KEY, JSON.stringify(collect())); } catch (e) {} }
  function load() {
    try { var raw = localStorage.getItem(STORE_KEY); if (raw) apply(JSON.parse(raw)); } catch (e) {}
  }

  /* ---------- Mirrors (type once, fill everywhere) ---------- */
  var mirrors = Array.prototype.slice.call(document.querySelectorAll("[data-mirror]"));
  function mirror() {
    mirrors.forEach(function (m) {
      var src = $(m.getAttribute("data-mirror"));
      if (!src) return;
      var v = getVal(src);
      if ("value" in m) m.value = v; else m.textContent = v;
    });
  }

  /* ---------- Validation ---------- */
  function isPan(v) { return /^[A-Z]{5}[0-9]{4}[A-Z]$/.test(String(v || "").toUpperCase()); }
  function clearInvalid() {
    form.querySelectorAll(".invalid").forEach(function (el) { el.classList.remove("invalid"); });
  }
  function labelFor(el) {
    var f = el.closest(".field");
    var sp = f && f.querySelector("span");
    var t = sp ? sp.textContent : el.id;
    return String(t || el.id).replace(/\*/g, "").trim();
  }
  // Returns an error message for a non-empty value with a recognisable format,
  // or null when the value is empty or valid.
  function formatError(el) {
    var v = String(getVal(el) || "").trim();
    if (!v) return null;
    var id = (el.id || "").toLowerCase();
    var name = (el.name || "").toLowerCase();
    if (el.classList.contains("pan")) return isPan(v) ? null : "enter a valid PAN (e.g. ABCDE1234F)";
    if (el.type === "email") return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v) ? null : "enter a valid email address";
    if (id.indexOf("ifsc") > -1) return /^[A-Z]{4}0[A-Z0-9]{6}$/.test(v.toUpperCase()) ? null : "enter a valid IFSC (e.g. SBIN0001234)";
    if (id.indexOf("aadhaar") > -1) return /^\d{12}$/.test(v) ? null : "Aadhaar must be 12 digits";
    if (id.indexOf("pran") > -1) return /^\d{12}$/.test(v) ? null : "PRAN must be 12 digits";
    if (el.type === "tel" || id.indexOf("mobile") > -1 || name.indexOf("mobile") > -1) return /^[6-9]\d{9}$/.test(v) ? null : "mobile must be 10 digits starting 6\u20139";
    if (id === "pin" || id.indexOf("pincode") > -1) return /^\d{6}$/.test(v) ? null : "PIN code must be 6 digits";
    if (el.type === "date") {
      var d = new Date(v);
      if (isNaN(d.getTime())) return "enter a valid date";
      if (id.indexOf("dob") > -1) {
        var today = new Date(); today.setHours(0, 0, 0, 0);
        if (d > today) return "date of birth cannot be in the future";
      }
    }
    return null;
  }
  function runValidation() {
    clearInvalid();
    var firstBad = null, issues = [];
    controls().forEach(function (el) {
      var v = String(getVal(el)).trim();
      if (el.required && !v) {
        el.classList.add("invalid");
        if (!firstBad) firstBad = el;
        issues.push(labelFor(el) + ": required");
        return;
      }
      var fe = formatError(el);
      if (fe) {
        el.classList.add("invalid");
        if (!firstBad) firstBad = el;
        issues.push(labelFor(el) + ": " + fe);
      }
    });
    return { ok: !firstBad, firstBad: firstBad, issues: issues };
  }
  function focusBad(r) {
    if (!r.firstBad) return;
    r.firstBad.scrollIntoView({ behavior: "smooth", block: "center" });
    try { r.firstBad.focus({ preventScroll: true }); } catch (e) {}
  }
  function validate() {
    var r = runValidation();
    if (!r.ok) {
      focusBad(r);
      toast(r.issues.length + " issue(s) \u2014 " + r.issues[0]);
    }
    return r.ok;
  }
  function validateOnly() {
    var r = runValidation();
    if (r.ok) {
      toast("\u2713 All entries look valid.");
    } else {
      focusBad(r);
      toast("\u26A0 " + r.issues.length + " issue(s) \u2014 fix highlighted fields. First: " + r.issues[0]);
    }
  }

  /* ---------- Sample / clear ---------- */
  function fillSample() {
    if (!SAMPLE) { toast("No sample data for this form."); return; }
    apply(SAMPLE);
    save();
    toast("Sample data filled.");
  }
  function clearAll() {
    if (!confirm("Clear all fields? This cannot be undone.")) return;
    controls().forEach(function (el) {
      if (el.type === "checkbox" || el.type === "radio") el.checked = false;
      else el.value = "";
    });
    clearInvalid();
    mirror();
    save();
    toast("Form cleared.");
  }

  /* ---------- CSV ---------- */
  function csvEscape(v) {
    v = String(v == null ? "" : v);
    return /[",\n]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
  }
  function exportCSV() {
    var data = collect();
    var rows = [["field", "value"]];
    Object.keys(data).forEach(function (k) { rows.push([k, data[k]]); });
    var csv = rows.map(function (r) { return r.map(csvEscape).join(","); }).join("\r\n");
    var blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    var a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = (window.FORM_NAME || "form") + ".csv";
    a.click();
    URL.revokeObjectURL(a.href);
    toast("CSV exported.");
  }
  function parseCSV(text) {
    var rows = [], row = [], cur = "", q = false;
    for (var i = 0; i < text.length; i++) {
      var c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cur += '"'; i++; } else q = false; }
        else cur += c;
      } else {
        if (c === '"') q = true;
        else if (c === ",") { row.push(cur); cur = ""; }
        else if (c === "\n") { row.push(cur); rows.push(row); row = []; cur = ""; }
        else if (c !== "\r") cur += c;
      }
    }
    if (cur !== "" || row.length) { row.push(cur); rows.push(row); }
    return rows;
  }
  function importCSV(file) {
    var reader = new FileReader();
    reader.onload = function () {
      try {
        var rows = parseCSV(String(reader.result));
        var data = {};
        rows.slice(1).forEach(function (r) { if (r[0]) data[r[0]] = r[1] != null ? r[1] : ""; });
        apply(data);
        save();
        toast("CSV imported.");
      } catch (e) { toast("Could not read CSV file."); }
    };
    reader.readAsText(file);
  }

  /* ---------- Preview ---------- */
  function measureFit() {
    var MM = 3.7795275591;
    var doc = document.querySelector(".doc");
    var docMM = (doc ? doc.getBoundingClientRect().height : 0) / MM;
    var pages = document.querySelectorAll(".part-bar.pagebreak").length + 1;
    var availMM = (297 - 20) * pages;
    var banner = $("previewBanner");
    if (!banner) return;
    banner.hidden = false;
    if (docMM > availMM + 1) {
      banner.className = "preview-banner no-print over";
      banner.textContent = "\u26A0 Content is long (~" + Math.round(docMM) + "mm) \u2014 it may exceed " + pages + " page(s).";
    } else {
      banner.className = "preview-banner no-print fit";
      banner.textContent = "\u2713 Print layout ready (\u2248 " + pages + " A4 page" + (pages > 1 ? "s" : "") + ").";
    }
  }
  function setPreview(on) {
    document.body.classList.toggle("preview-mode", on);
    var btn = $("btnPreview");
    if (btn) btn.textContent = on ? "Exit Preview" : "Preview";
    if (on) requestAnimationFrame(measureFit);
    else { var b = $("previewBanner"); if (b) b.hidden = true; }
  }

  /* ---------- Wire up ---------- */
  function onInput(e) {
    var t = e.target;
    if (t && t.classList && t.classList.contains("invalid")) t.classList.remove("invalid");
    mirror();
    save();
  }

  document.addEventListener("DOMContentLoaded", function () {
    load();
    mirror();
    form.addEventListener("input", onInput);
    form.addEventListener("change", onInput);

    var bind = function (id, fn, evt) { var el = $(id); if (el) el.addEventListener(evt || "click", fn); };
    bind("btnSample", fillSample);
    bind("btnClear", clearAll);
    bind("btnExport", exportCSV);
    bind("importCsv", function (e) {
      if (e.target.files && e.target.files[0]) importCSV(e.target.files[0]);
      e.target.value = "";
    }, "change");
    bind("btnPreview", function () { setPreview(!document.body.classList.contains("preview-mode")); });
    bind("btnPrint", function () { if (validate()) window.print(); });

    // Floating "Validate" action button (format + date + mandatory checks).
    if (!$("fabValidate")) {
      var fab = document.createElement("button");
      fab.type = "button";
      fab.id = "fabValidate";
      fab.className = "fab no-print";
      fab.title = "Validate the details you entered";
      fab.innerHTML = '<span class="fab-ic">\u2713</span><span class="fab-tx">Validate</span>';
      fab.addEventListener("click", validateOnly);
      document.body.appendChild(fab);
    }
  });
})();
